
package st10284733_progpart2_pranayappanna;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import javax.swing.JOptionPane;

@RunWith(JUnit4.class)
public class TaskTest {

    private static Object getNumberOfTasks() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    private static boolean Login() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Before
    public void setUp() {
        // Set up any necessary resources before each test
    }

    @After
    public void tearDown() {
        // Clean up resources after each test
    }

    @Test
    public void testLoginSuccessful() {
        assertTrue(TaskTest.Login());
    }

    @Test
    public void testGetNumberOfTasks() {
        // Mock user input
        JOptionPaneTestUtil.setInput("5");
        // Expectation
        assertEquals(5, TaskTest.getNumberOfTasks());
    }

    @Test
    public void testShowMainMenu() {
        // Mock user input
        JOptionPaneTestUtil.setOption(1);
        // Expectation
        assertEquals(1, EasyKanbanApp.showMainMenu());
    }

    @Test
    public void testAddTasks() {
        // Mock output
        JOptionPaneTestUtil.setExpectedOutput("Adding 5 tasks...");
        // Call the method
        EasyKanbanApp.addTasks(5);
        // Check if message is displayed
        assertEquals(JOptionPaneTestUtil.Getoutput(), JOptionPaneTestUtil.getExpectedOutput());
    }

    @Test
    public void testShowReport() {
        // Mock output
        JOptionPaneTestUtil.setExpectedOutput("This feature is still in development. Coming Soon!");
        // Call the method
        EasyKanbanApp.showReport();
        // Check if message is displayed
        assertEquals(JOptionPaneTestUtil.getOutput(), JOptionPaneTestUtil.getExpectedOutput());
    }

    private static class EasyKanbanApp {

        private static Object showMainMenu() {
            throw new UnsupportedOperationException("Not supported yet."); 
        }

        private static void addTasks(int i) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        private static void showReport() {
            throw new UnsupportedOperationException("Not supported yet."); 
        }

        public EasyKanbanApp() {
        }
    }
}