package st10284733_progpart2_pranayappanna;
 import javax.swing.JOptionPane;
public class Task {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

        boolean loggedIn = login();

        if (loggedIn) {
            int numTasks = getNumberOfTasks();

            int choice;
            do {
                choice = showMainMenu();
                switch (choice) {
                    case 1:
                        addTasks(numTasks);
                        break;
                    case 2:
                        showReport();
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null, "Exiting EasyKanban. Goodbye!");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                }
            } while (choice != 3);
        } else {
            JOptionPane.showMessageDialog(null, "Login unsuccessful. Exiting EasyKanban.");
        }
    }

    private static boolean login() {
        return true;
    }

    private static int getNumberOfTasks() {
        // Get number of tasks from user
        String input = JOptionPane.showInputDialog("Enter the number of tasks:");
        return Integer.parseInt(input);
    }

    private static int showMainMenu() {
        String[] options = {"Add tasks", "Show report", "Quit"};
        int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Main Menu", JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        return choice + 1;
    }

    private static void addTasks(int numTasks) {
        JOptionPane.showMessageDialog(null, "Adding " + numTasks + " tasks...");
    }

    private static void showReport() {
        JOptionPane.showMessageDialog(null, "This feature is still in development. Coming Soon!");
    }
}

